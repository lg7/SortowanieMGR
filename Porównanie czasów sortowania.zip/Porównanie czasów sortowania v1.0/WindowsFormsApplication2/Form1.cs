﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        int[] tablicaLiczb;
        int iloscLiczb;
        int[] sortowanieBabelkowe;
        int[] instertSort;
        int[] selectionSort;
        int[] mergeSort;

        public Form1()
        {
            InitializeComponent();
        }

        private void generujLiczbyLosowe()
        {
            Random rand = new Random();
            for (int i = 0; i < iloscLiczb; i++) //dla elementow od 0 do iloscLiczb-1
            {
                tablicaLiczb[i] = rand.Next() % 1000;  //wpisz wygenerowana liczbe do tablicy
            }
        }

        //przycisk generuj liczby
        private void button1_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            if (Int32.TryParse(textBox1.Text.ToString(), out iloscLiczb))
            {
                tablicaLiczb = new int[iloscLiczb];
                generujLiczbyLosowe();
                button2.Enabled = true;
                button3.Enabled = true;

                sortowanieBabelkowe = new int[iloscLiczb];
                instertSort = new int[iloscLiczb];
                selectionSort = new int[iloscLiczb];
                mergeSort = new int[iloscLiczb];

                for (int i = 0; i < iloscLiczb; i++)
                {
                    sortowanieBabelkowe[i] = tablicaLiczb[i];
                    instertSort[i] = tablicaLiczb[i];
                    selectionSort[i] = tablicaLiczb[i];
                    mergeSort[i] = tablicaLiczb[i];
                }
            }
            else
            {
                MessageBox.Show("Podaj ilosc liczb, ktore chcesz posortowac");
            }
            Cursor.Current = Cursors.Default;
        }

        //przycisk pokaz liczby
        private void button3_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            //MessageBox.Show(liczby);
            Form2 pokaz = new Form2(tablicaLiczb, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        //przycisk sortowanie jednordzeniowe
        private void button2_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            Stopwatch sw = new Stopwatch();
            Stopwatch calkowityCzas = new Stopwatch();

            calkowityCzas.Start();
            //Sortowanie bąbelkowe            
            sw.Start();
            algorytmSortowanieBabelkowe();
            sw.Stop();
            textBox2.Text = sw.ElapsedMilliseconds.ToString();
            textBox2.Update();

            //Sortowanie Insert Sort
            sw.Reset();
            sw.Start();
            algorytmInsertSort();
            sw.Stop();
            textBox3.Text = sw.ElapsedMilliseconds.ToString();
            textBox3.Update();

            //Sortowanie Selkection Sort
            sw.Reset();
            sw.Start();
            algorytmSelectionSort();
            sw.Stop();
            textBox4.Text = sw.ElapsedMilliseconds.ToString();
            textBox4.Update();

            //Sortowanie merge Sort
            sw.Reset();
            sw.Start();
            algorytmMergeSort(0, iloscLiczb-1);
            sw.Stop();
            textBox5.Text = sw.ElapsedMilliseconds.ToString();
            textBox5.Update();

            calkowityCzas.Stop();
            textBox6.Text = calkowityCzas.ElapsedMilliseconds.ToString();
            textBox6.Update();

            Cursor.Current = Cursors.Default;
        }

        void algorytmSortowanieBabelkowe()
        {
            for (int i = 0; i < iloscLiczb; i++)
            {
                for (int j = 0; j < iloscLiczb - 1; j++)
                {
                    if (sortowanieBabelkowe[j] > sortowanieBabelkowe[j + 1])
                    {
                        int temp = sortowanieBabelkowe[j];
                        sortowanieBabelkowe[j] = sortowanieBabelkowe[j + 1];
                        sortowanieBabelkowe[j + 1] = temp;   
                    }
                }
            }
        }

        void algorytmInsertSort ()
        {
            int i, j, x;
            for(j = iloscLiczb - 2; j >= 0; j--)
            {
                x = instertSort[j];
                i = j + 1;
                while ((i < iloscLiczb) && (x > instertSort[i]))
                {
                    instertSort[i - 1] = instertSort[i];
                    i++;
                }
                instertSort[i - 1] = x;
            }
        }
        
        //funkcja szukacja minimalnego elementu w tablicy
        int selectionSortSzukajNajmniejszego (int p, int k)
        {
            int minimum = p;    //na poczatek ustawimy sobie minimum na pierwszy element naszego przedzialu

            for ( int i = p; i < k; i++ )  //dla kazdego elementu przedzialu "p" do "k"
            {
                if (selectionSort[minimum] > selectionSort[i]) minimum = i; //jezeli biezacy element jest mniejszy od naszego minimum to ustawiamy wlasnie jego jako minimum
            }
            return minimum; //zwracamy znaleziona wartosc minimum
        }

        void algorytmSelectionSort()
        {
            int najamniejszyElement;

            for (int i = 0; i < iloscLiczb; i++)    //dla kazdego elementu naszej tablicy
            {
                najamniejszyElement = selectionSortSzukajNajmniejszego(i, iloscLiczb); //do zmiennej pomocniczej zapisujemy wartosc najmniejszego elementu z pprzedzialu od i do n
                
                //przestawiamy najsmniejszy element z elementem biezacym z indeksem "i"
                int temp = selectionSort[najamniejszyElement];    //do zmiennej pomocniczej zapiszemy sobie wartosc w tablicy T[j]
                selectionSort[najamniejszyElement] = selectionSort[i];    //do T[j] zapisujemy wartosc z T[k]
                selectionSort[i] = temp;    //do T[k] zapisujemy wartosc z naszej zmiennej pomocniczej
            }
        }

        void merge(int l, int m, int r) 
        { 
            int i, j, k; 
            int n1 = m - l + 1; 
            int n2 =  r - m; 
  
            // tymczasowe tablice pomocnicze
            int [] L = new int [n1];
            int [] R = new int [n2];
  
            //wypelnienie tymczasowych tablic
            for (i = 0; i < n1; i++) 
                L[i] = mergeSort[l + i]; 
            for (j = 0; j < n2; j++) 
                R[j] = mergeSort[m + 1+ j]; 
  
            // Scalenie tablic pomocniczych do tablicy T[l..r]
            i = 0; //indeks poczatkowy pierwszej tablicy pomocniczej
            j = 0; //indeks poczatkowy drugiej tablicy pomocniczej
            k = l; //indeks poczatkowy scalonej tablicy
            while (i < n1 && j < n2) 
            { 
                if (L[i] <= R[j]) 
                { 
                    mergeSort[k] = L[i]; 
                    i++; 
                } 
                else
                { 
                    mergeSort[k] = R[j]; 
                    j++; 
                } 
                k++; 
            } 
  
            //kopiowanie reszty tablicy L[], o ile cos w niej zostalo
            while (i < n1) 
            { 
                mergeSort[k] = L[i]; 
                i++; 
                k++; 
            } 
  
            //kopiowanie reszty tablicy R[], o ile cos w niej zostalo
            while (j < n2) 
            { 
                mergeSort[k] = R[j]; 
                j++; 
                k++; 
            } 
        } 

        void algorytmMergeSort(int l, int r) 
        { 
            if (l < r) 
            { 
                //obliczaine polowy przedzialu
                // to samo co (l+r)/2, ale chroni przed wyjsciem poza zakres int przy 
                // duzym l i h 
                int m = l+(r-l)/2; 
  
                // rekurencyjne sortowanie pierwszej i drugiej polowki
                algorytmMergeSort(l, m);
                algorytmMergeSort(m+1, r); 
  
                merge(l, m, r); 
            } 
        } 
        
        private void button5_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(sortowanieBabelkowe, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(instertSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(selectionSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(mergeSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
