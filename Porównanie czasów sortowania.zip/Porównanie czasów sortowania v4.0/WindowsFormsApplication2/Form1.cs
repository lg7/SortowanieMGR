﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        int[] tablicaLiczb;
        int iloscLiczb;
        int[] sortowanieBabelkowe;
        int[] instertSort;
        //int[] selectionSort;
        int[] mergeSort;
        int[] quickSort;
        int[] bitonicTab;


        public Form1()
        {
            InitializeComponent();
        }

        private void generujLiczbyLosowe()
        {
            Random rand = new Random();
            for (int i = 0; i < iloscLiczb; i++) //dla elementow od 0 do iloscLiczb-1
            {
                tablicaLiczb[i] = rand.Next() % 1000;  //wpisz wygenerowana liczbe do tablicy
            }
        }

        //przycisk generuj liczby
        private void button1_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            if (Int32.TryParse(textBox1.Text.ToString(), out iloscLiczb))
            {
                tablicaLiczb = new int[iloscLiczb];
                generujLiczbyLosowe();
                button2.Enabled = true;
                button3.Enabled = true;
                button8.Enabled = true;

                sortowanieBabelkowe = new int[iloscLiczb];
                instertSort = new int[iloscLiczb];
                //selectionSort = new int[iloscLiczb];
                mergeSort = new int[iloscLiczb];
                quickSort = new int[iloscLiczb];
                bitonicTab = new int[iloscLiczb];
            }
            else
            {
                MessageBox.Show("Podaj ilosc liczb, ktore chcesz posortowac");
            }

            for (int i = 0; i < iloscLiczb; i++)
            {
                sortowanieBabelkowe[i] = tablicaLiczb[i];
                instertSort[i] = tablicaLiczb[i];
                //selectionSort[i] = tablicaLiczb[i];
                mergeSort[i] = tablicaLiczb[i];
                quickSort[i] = tablicaLiczb[i];
                bitonicTab[i] = tablicaLiczb[i];
            }
            Cursor.Current = Cursors.Default;
        }

        //przycisk pokaz liczby
        private void button3_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            //MessageBox.Show(liczby);
            Form2 pokaz = new Form2(tablicaLiczb, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        //przycisk sortowanie jednordzeniowe
        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < iloscLiczb; i++)
            {
                sortowanieBabelkowe[i] = tablicaLiczb[i];
                instertSort[i] = tablicaLiczb[i];
                //selectionSort[i] = tablicaLiczb[i];
                mergeSort[i] = tablicaLiczb[i];
                quickSort[i] = tablicaLiczb[i];
                bitonicTab[i] = tablicaLiczb[i];
            }

            Cursor.Current = Cursors.WaitCursor;

            Stopwatch sw = new Stopwatch();
            Stopwatch calkowityCzas = new Stopwatch();

            calkowityCzas.Start();

            if (bubbleCheck.Checked)
            {
                //Sortowanie bąbelkowe            
                sw.Start();
                sortowanieBabelkowe = algorytmSortowanieBabelkowe(sortowanieBabelkowe, iloscLiczb);
                sw.Stop();
                textBox2.Text = sw.ElapsedMilliseconds.ToString();
                textBox2.Update();
            }

            if (quickCheck.Checked)
            {
                //Sortowanie  quicksort
                sw.Reset();
                sw.Start();
                quickSort = algorytmQuickSort(quickSort, 0, iloscLiczb - 1);
                sw.Stop();
                textBox3.Text = sw.ElapsedMilliseconds.ToString();
                textBox3.Update();
            }

            if (insertCheck.Checked)
            {
                //Sortowanie insert Sort
                sw.Reset();
                sw.Start();
                instertSort = algorytmInsertSort(instertSort, iloscLiczb);
                sw.Stop();
                textBox4.Text = sw.ElapsedMilliseconds.ToString();
                textBox4.Update();
            }

            if (mergeCheck.Checked)
            {
                //Sortowanie merge Sort
                sw.Reset();
                sw.Start();
                algorytmMergeSort(0, iloscLiczb - 1);
                sw.Stop();
                textBox5.Text = sw.ElapsedMilliseconds.ToString();
                textBox5.Update();
            }

            if (bitonicCheck.Checked)
            {
                //Sortowanie merge Sort
                sw.Reset();
                sw.Start();
                bitonicSort(bitonicTab, 0, iloscLiczb, true);
                sw.Stop();
                textBox13.Text = sw.ElapsedMilliseconds.ToString();
                textBox13.Update();
            }

            calkowityCzas.Stop();
            textBox6.Text = calkowityCzas.ElapsedMilliseconds.ToString();
            textBox6.Update();

            Cursor.Current = Cursors.Default;
        }

        private int[] algorytmSortowanieBabelkowe(int[] T, int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n - 1; j++)
                {
                    if (T[j] > T[j + 1])
                    {
                        int temp = T[j];
                        T[j] = T[j + 1];
                        T[j + 1] = temp;
                    }
                }
            }
            return T;
        }

        private int[] algorytmInsertSort(int[] T, int n)
        {
            int i, j, x;
            for(j = iloscLiczb - 2; j >= 0; j--)
            {
                x = T[j];
                i = j + 1;
                while ((i < iloscLiczb) && (x > T[i]))
                {
                    T[i - 1] = T[i];
                    i++;
                }
                T[i - 1] = x;
            }
            return T;
        }

        private void krok1RownoleglyAlgorytmInsertSort(int[] T, int i)
        {
            if (T[i] < T[i - 1])
                {
                    int temp = T[i];
                    T[i] = T[i - 1];
                    T[i - 1] = temp;
                }
        }

        private void krok2RownoleglyAlgorytmInsertSort(int[] T, int i)
        {
            int j = i;
            int v = T[i];
            while (v < T[j - 1])
            {
                T[j] = T[j - 1];
                j--;
            }
            T[j] = v;
        }

        private int[] rownoleglyAlgorytmInsertSort(int[] T, int n)
        {
            for (int i = iloscLiczb - 1; i > 0; i--)
            {
                //k = iloscLiczb - 1;
                /*if (T[i] < T[i - 1])
                {
                    int temp = T[i];
                    T[i] = T[i - 1];
                    T[i - 1] = temp;
                }*/

                Parallel.Invoke(
                    () => krok1RownoleglyAlgorytmInsertSort(T, i));
            }

            for (int i = 2; i <= (iloscLiczb - 1); i++)
            {
                /*int j = i;
                int v = T[i];
                while (v < T[j - 1])
                {
                    T[j] = T[j - 1];
                    j--;
                }
                T[j] = v;*/

                Parallel.Invoke(
                    () => krok2RownoleglyAlgorytmInsertSort(T, i)); 
            }

            return T;
        }

        private int[] algorytmQuickSort(int[] T, int lewy, int prawy)
        {
            if (lewy >= prawy)
            {
                return T;
            }

             int i = lewy;
             int j = prawy;
             int pivot = T[(lewy + prawy) / 2];
             do{
                 while(T[i] < pivot) i++;
                 while(T[j] > pivot) j--;
                 if(i<=j){
                     int temp = T[i];
                     T[i] = T[j];
                     T[j] = temp;
                     i++;
                     j--;
                 }
             }while(i <= j);

             algorytmQuickSort(T, lewy, j);
             algorytmQuickSort(T, i, prawy);
             return T;
        }

        private void algorytmRownoleglyQuickSort(int[] T, int lewy, int prawy, int glebokoscWatkow)
        {

            if (lewy >= prawy)
            {
                return;
            }

            int i = lewy;
            int j = prawy;
            int pivot = T[(lewy + prawy) / 2];
            do
            {
                while (T[i] < pivot) i++;
                while (T[j] > pivot) j--;
                if (i <= j)
                {
                    int temp = T[i];
                    T[i] = T[j];
                    T[j] = temp;
                    i++;
                    j--;
                }
            } while (i <= j);

            if (glebokoscWatkow < 1)
            {
                algorytmRownoleglyQuickSort(T, lewy, j, glebokoscWatkow);
                algorytmRownoleglyQuickSort(T, i, prawy, glebokoscWatkow);
            }
            else
            {
                glebokoscWatkow--;
                Parallel.Invoke(
                    () => algorytmRownoleglyQuickSort(T, lewy, j, glebokoscWatkow),
                    () => algorytmRownoleglyQuickSort(T, i, prawy, glebokoscWatkow));
            }           
        }

        public static void compAndSwap(int[] T, int i, int j, bool dir)
        {
            bool k;
            if ((T[i] > T[j]))
                k = true;
            else
                k = false;
            if (dir == k)
            {
                int temp;
                temp = T[i];
                T[i] = T[j];
                T[j] = temp; 
            }
        }

        private static int najwiekszaPotegaMniejszaOd(int n)
        {
            int potega = 1;

            while (potega > 0 && potega < n)
                potega = potega << 1;
       
            return potega >> 1;
        }
        
        public static void bitonicMerge(int[] T, int low, int cnt, bool dir)
        {
            if (cnt > 1)
            {
                int m = najwiekszaPotegaMniejszaOd(cnt);

                for (int i = low; i < (low + cnt - m); i++)
                    compAndSwap(T, i, i + m, dir);

                bitonicMerge(T, low, m, dir);
                bitonicMerge(T, low + m, cnt - m, dir);
            }
        }

        public static void bitonicSort(int[] T, int low, int cnt, bool dir)  
        {  
            if (cnt>1)  
            {  
                int k = cnt/2;  
        
                // sort in ascending order since dir here is 1  
                bitonicSort(T, low, k, !dir);  
        
                // sort in descending order since dir here is 0  
                bitonicSort(T, low+k, cnt - k, dir);  
        
                // Will merge wole sequence in ascending order  
                // since dir=1.  
                bitonicMerge(T, low, cnt, dir);  
            }  
        }

        public static void rownoleglyBitonicMerge(int[] T, int low, int cnt, bool dir)
        {
            if (cnt > 500)
            {
                int m = najwiekszaPotegaMniejszaOd(cnt);

                for (int i = low; i < (low + cnt - m); i++)
                    compAndSwap(T, i, i + m, dir);
                Parallel.Invoke(
                        () => rownoleglyBitonicMerge(T, low, m, dir),
                        () => rownoleglyBitonicMerge(T, low + m, cnt - m, dir));
            }
            else if (cnt > 1)
            {
                bitonicMerge(T, low, cnt, dir);
            }
        }

        public static void rownoleglyBitonicSort(int[] T, int low, int cnt, bool dir)
        {
            if (cnt > 1)
            {
                int k = cnt / 2;

               Parallel.Invoke(
                        () => rownoleglyBitonicSort(T, low, k, !dir),
                        () => rownoleglyBitonicSort(T, low + k, cnt - k, dir));

                // Will merge wole sequence in ascending order  
                // since dir=1.  
               rownoleglyBitonicMerge(T, low, cnt, dir);
            }
        }  

        /*//funkcja szukacja minimalnego elementu w tablicy
        int selectionSortSzukajNajmniejszego (int p, int k)
        {
            int minimum = p;    //na poczatek ustawimy sobie minimum na pierwszy element naszego przedzialu

            for ( int i = p; i < k; i++ )  //dla kazdego elementu przedzialu "p" do "k"
            {
                if (selectionSort[minimum] > selectionSort[i]) minimum = i; //jezeli biezacy element jest mniejszy od naszego minimum to ustawiamy wlasnie jego jako minimum
            }
            return minimum; //zwracamy znaleziona wartosc minimum
        }

        void algorytmSelectionSort()
        {
            int najamniejszyElement;

            for (int i = 0; i < iloscLiczb; i++)    //dla kazdego elementu naszej tablicy
            {
                najamniejszyElement = selectionSortSzukajNajmniejszego(i, iloscLiczb); //do zmiennej pomocniczej zapisujemy wartosc najmniejszego elementu z pprzedzialu od i do n
                
                //przestawiamy najsmniejszy element z elementem biezacym z indeksem "i"
                int temp = selectionSort[najamniejszyElement];    //do zmiennej pomocniczej zapiszemy sobie wartosc w tablicy T[j]
                selectionSort[najamniejszyElement] = selectionSort[i];    //do T[j] zapisujemy wartosc z T[k]
                selectionSort[i] = temp;    //do T[k] zapisujemy wartosc z naszej zmiennej pomocniczej
            }
        }*/

        void merge(int l, int m, int r) 
        { 
            int i, j, k; 
            int n1 = m - l + 1; 
            int n2 =  r - m; 
  
            // tymczasowe tablice pomocnicze
            int [] L = new int [n1];
            int [] R = new int [n2];
  
            //wypelnienie tymczasowych tablic
            for (i = 0; i < n1; i++) 
                L[i] = mergeSort[l + i]; 
            for (j = 0; j < n2; j++) 
                R[j] = mergeSort[m + 1+ j]; 
  
            // Scalenie tablic pomocniczych do tablicy T[l..r]
            i = 0; //indeks poczatkowy pierwszej tablicy pomocniczej
            j = 0; //indeks poczatkowy drugiej tablicy pomocniczej
            k = l; //indeks poczatkowy scalonej tablicy
            while (i < n1 && j < n2) 
            { 
                if (L[i] <= R[j]) 
                { 
                    mergeSort[k] = L[i]; 
                    i++; 
                } 
                else
                { 
                    mergeSort[k] = R[j]; 
                    j++; 
                } 
                k++; 
            } 
  
            //kopiowanie reszty tablicy L[], o ile cos w niej zostalo
            while (i < n1) 
            { 
                mergeSort[k] = L[i]; 
                i++; 
                k++; 
            } 
  
            //kopiowanie reszty tablicy R[], o ile cos w niej zostalo
            while (j < n2) 
            { 
                mergeSort[k] = R[j]; 
                j++; 
                k++; 
            } 
        } 

        void algorytmMergeSort(int l, int r) 
        { 
            if (l < r) 
            { 
                //obliczaine polowy przedzialu
                // to samo co (l+r)/2, ale chroni przed wyjsciem poza zakres int przy 
                // duzym l i h 
                int m = l+(r-l)/2; 
  
                // rekurencyjne sortowanie pierwszej i drugiej polowki
                algorytmMergeSort(l, m);
                algorytmMergeSort(m+1, r); 
  
                merge(l, m, r); 
            } 
        }

        void algorytmRownoleglyMergeSort(int l, int r, int glebokosc)
        {
            if (l < r)
            {
                //obliczaine polowy przedzialu
                // to samo co (l+r)/2, ale chroni przed wyjsciem poza zakres int przy 
                // duzym l i r 
                int m = l + (r - l) / 2;

                if (glebokosc < 1)
                {
                    algorytmRownoleglyMergeSort(l, m, glebokosc);
                    algorytmRownoleglyMergeSort(m + 1, r, glebokosc);
                }
                else
                {
                    glebokosc--;
                    Parallel.Invoke(
                        () => algorytmRownoleglyMergeSort(l, m, glebokosc),
                        () => algorytmRownoleglyMergeSort(m + 1, r, glebokosc));
                       
                }
                merge(l, m, r);
            }
        }   

        /*void heapify(int[] T, int n, int i)
        {
            int largest = i; //Zainicjuj najwiêkszy jako "korzen"
            int l = 2 * i + 1; // left = 2*i + 1
            int r = 2 * i + 2; // right = 2*i + 2

            //jesli lewy element jest wiekszy niz "korzen"
            if (l < n && T[l] > T[largest])
                largest = l;

            //jesli prawy element jest wiekszy niz "korzen"
            if (r < n && T[r] > T[largest])
                largest = r;

            //jesli "korzen" nie jest najwiekszy
            if (largest != i) {
                //swap(T[i], T[largest]);
                int temp = T[i];
                T[i] = T[largest];
                T[largest] = temp; 
                //rekurencyjne wywolanie budowania kopca
                heapify(T, n, largest);
            }
        }

        void heapSort(int[] T, int n)
        {
            //budowanie kopca
            for (int i = n / 2 - 1; i >= 0; i--)
                heapify(T, n, i);

            //Jeden po drugim wypakuj element z kopca
            for (int i = n - 1; i >= 0; i--) 
            {
                // Move current root to end
                //swap(T[0], T[i]);
                int temp = T[i];
                T[i] = T[0];
                T[0] = temp; 
                //wywolanie budowania kocpa na zredukowanym kopcu
                heapify(T, i, 0);
            }
        }*/
      
        private int[] rownoolegleSortowanieBalbelkowe(int [] T, int n)
        {
            Parallel.For (0, n, i =>
            {      
                for (int j = 0; j < n - 1; j++)
                {
                    if (T[j] > T[j + 1])
                    {
                        int temp = T[j];
                        T[j] = T[j + 1];
                        T[j + 1] = temp; 
                    }
                }
            });
            return T;
        }

        //funkcja sprawdzająca
        private bool sprawdz(int[] T, int n)
        {
            for (int i = 0; i < (n - 1); i++)
            {
                if (T[i] > T[i + 1]) return false;
            }
            return true;
        }

        //przycisk sortowanie wielowatkowe
        private void button8_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < iloscLiczb; i++)
            {
                sortowanieBabelkowe[i] = tablicaLiczb[i];
                instertSort[i] = tablicaLiczb[i];
                //selectionSort[i] = tablicaLiczb[i];
                mergeSort[i] = tablicaLiczb[i];
                quickSort[i] = tablicaLiczb[i];
                bitonicTab[i] = tablicaLiczb[i];
            }

            Cursor.Current = Cursors.WaitCursor;

            Stopwatch sw = new Stopwatch();
            Stopwatch calkowityCzas = new Stopwatch();

            calkowityCzas.Start();

            if (bubbleCheck.Checked)
            {
                //Sortowanie bubble Sort
                sw.Reset();
                sw.Start();
                sortowanieBabelkowe = rownoolegleSortowanieBalbelkowe(sortowanieBabelkowe, iloscLiczb);
                sw.Stop();
                textBox11.Text = sw.ElapsedMilliseconds.ToString();
                textBox11.Update();
            }

            if (quickCheck.Checked)
            {
                //Sortowanie quicksort
                sw.Reset();
                sw.Start();
                algorytmRownoleglyQuickSort(quickSort, 0, iloscLiczb - 1, Environment.ProcessorCount);
                sw.Stop();
                textBox10.Text = sw.ElapsedMilliseconds.ToString();
                textBox10.Update();
            }

            if (insertCheck.Checked)
            {
                sw.Reset();
                sw.Start();
                instertSort = rownoleglyAlgorytmInsertSort(instertSort, iloscLiczb);
                sw.Stop();
                textBox9.Text = sw.ElapsedMilliseconds.ToString();
                textBox9.Update();
            }

            if (mergeCheck.Checked)
            {
                sw.Reset();
                sw.Start();
                algorytmRownoleglyMergeSort(0, iloscLiczb - 1, Environment.ProcessorCount);
                sw.Stop();
                textBox8.Text = sw.ElapsedMilliseconds.ToString();
                textBox8.Update();
            }

            if (bitonicCheck.Checked)
            {
                sw.Reset();
                sw.Start();
                rownoleglyBitonicSort(bitonicTab, 0, iloscLiczb, true);
                sw.Stop();
                textBox12.Text = sw.ElapsedMilliseconds.ToString();
                textBox12.Update();
            }

            calkowityCzas.Stop();
            textBox7.Text = calkowityCzas.ElapsedMilliseconds.ToString();
            textBox7.Update();

            Cursor.Current = Cursors.Default;
        }

        //przyciski pokaz
        private void button5_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(sortowanieBabelkowe, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(quickSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(instertSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(mergeSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(bitonicTab, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }
        
        //przyciski sprawdz 
        private void button12_Click(object sender, EventArgs e)
        {
            if (sprawdz(sortowanieBabelkowe, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (sprawdz(quickSort, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (sprawdz(instertSort, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (sprawdz(mergeSort, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (sprawdz(bitonicTab, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

    }
}
