﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        int[] tablicaLiczb; //do tej tablicy generujemy na początku liczby losowe, w tej tablicy też one się cały czas znajdują i się nie sortują
        int iloscLiczb; //tutaj przechowujmey ilosc liczb

        //Inicjacje tablic, których używamy w programie, to nich przechowujemy liczby, które sortujemy. Dla każdego sortowania jest osobna tablica
        //Tablica jest wykorzystywana zarówno w sortowaniu jednowątkowych jak i wielowątkowym.
        int[] sortowanieBabelkowe;
        int[] instertSort;
        int[] mergeSort;
        int[] quickSort;
        int[] bitonicTab;

        //Konstruktor klasy, inicjacja komponentów form1
        public Form1()
        {
            InitializeComponent();
        }

        //Funkcja generująca liczby losowe. 
        //Liczby są generowane w zakresie 0 - 1000, odpowiada za to wyrażenie "% 1000", czyli dzielenie modulo 1000
        private void generujLiczbyLosowe()
        {
            Random rand = new Random();
            for (int i = 0; i < iloscLiczb; i++) //dla elementow od 0 do iloscLiczb-1
            {
                tablicaLiczb[i] = rand.Next() % 1000;  //wpisz wygenerowana liczbe do tablicy
            }
        }

        //funkcja sprawdzająca
        private bool sprawdz(int[] T, int n)
        {
            //pętlą przechodzimy przez wszystkie elementy tablicy
            for (int i = 0; i < (n - 1); i++)
            {
                if (T[i] > T[i + 1]) return false;  //zwaracamy false, w przypadku gdy liczba większa jest przed mniejszą
            }
            return true;    //jeśli funkcja nie zakończyła się wcześniej, czyli przeszliśmy całą pętle to zwarcamy true
        }


        ///////////////////////////////////////Przyciski na formie/////////////////////////////////////

        //przycisk generuj liczby
        private void button1_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;    //tutaj zmieniamy kursor, na kursor oczekiwania (klepsydra, kręcące się kółeczko,...)
            if (Int32.TryParse(textBox1.Text.ToString(), out iloscLiczb))   //w pól typu textbox tak odczytujemy liczbę (try parse) i odczytaną liczbę przechpowujemy w zmiennej ilość liczb
            {
                tablicaLiczb = new int[iloscLiczb]; //tworzymy tablicę, tą początkową
                generujLiczbyLosowe();  //teraz generujemy liczby
                
                //umożliwiamy naciskanie nieaktywnych do tej pory przycisków (sortowanie jednowątkowe, wielowątkowe i pokaż wygenerowane)
                button2.Enabled = true; 
                button3.Enabled = true;
                button8.Enabled = true;

                //tutaj tworzymy sobie nowe tablice, których używamy do sortowania
                sortowanieBabelkowe = new int[iloscLiczb];
                instertSort = new int[iloscLiczb];
                mergeSort = new int[iloscLiczb];
                quickSort = new int[iloscLiczb];
                bitonicTab = new int[iloscLiczb];
            }
            else  //tutaj wchodzimy, jeśli nie powiedzie się konwersja liczby z pola textowego1, czyli ilosć liczb. Zadzieje się tak jak ktoś wpisze np. litere
            {
                MessageBox.Show("Podaj ilosc liczb, ktore chcesz posortowac");
            }

            //tą pęttą kopijemy zawortość naszej początkowej tablicy do tablic pomocniczych
            for (int i = 0; i < iloscLiczb; i++)
            {
                sortowanieBabelkowe[i] = tablicaLiczb[i];
                instertSort[i] = tablicaLiczb[i];
                mergeSort[i] = tablicaLiczb[i];
                quickSort[i] = tablicaLiczb[i];
                bitonicTab[i] = tablicaLiczb[i];
            }
            Cursor.Current = Cursors.Default;   //zmienieamy kursor na normalny, domyślny
        }

        //przycisk pokaz liczby
        private void button3_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;    //tutaj zmieniamy kursor, na kursor oczekiwania (klepsydra, kręcące się kółeczko,...)
            Form2 pokaz = new Form2(tablicaLiczb, iloscLiczb);  //tworzymy obiekt form2 i przekazujemy do tego obiektu tablicę z liczbami i ilość liczb
            pokaz.Show();   //pokazujemy ten stworzony obiekt
            Cursor.Current = Cursors.Default;//zmienieamy kursor na normalny, domyślny
        }

        //przyciski pokaz
        //ogólnie wszystkie przyciski pokaz robią dokładnie to samo, przekazują tylko inną tablicę
        private void button5_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(sortowanieBabelkowe, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(quickSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(instertSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(mergeSort, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Form2 pokaz = new Form2(bitonicTab, iloscLiczb);
            pokaz.Show();
            Cursor.Current = Cursors.Default;
        }

        //przyciski sprawdz 

        private void button12_Click(object sender, EventArgs e)
        {
            if (sprawdz(sortowanieBabelkowe, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (sprawdz(quickSort, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (sprawdz(instertSort, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (sprawdz(mergeSort, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (sprawdz(bitonicTab, iloscLiczb)) MessageBox.Show("Liczby są posortowane");
            else MessageBox.Show("Liczby nie są posortowane");
        }

        //przycisk sortowanie jednordzeniowe
        private void button2_Click(object sender, EventArgs e)
        {
            //tą pęttą kopijemy zawortość naszej początkowej tablicy do tablic pomocniczych
            for (int i = 0; i < iloscLiczb; i++)
            {
                sortowanieBabelkowe[i] = tablicaLiczb[i];
                instertSort[i] = tablicaLiczb[i];
                mergeSort[i] = tablicaLiczb[i];
                quickSort[i] = tablicaLiczb[i];
                bitonicTab[i] = tablicaLiczb[i];
            }

            Cursor.Current = Cursors.WaitCursor;//tutaj zmieniamy kursor, na kursor oczekiwania (klepsydra, kręcące się kółeczko,...)

            Stopwatch sw = new Stopwatch();//tworzymy timer obliczający czas poszczególnych sortowań
            Stopwatch calkowityCzas = new Stopwatch();//tworzymy timer obliczający czas wszystkich sortowań

            calkowityCzas.Start();  //czas start

            if (bubbleCheck.Checked)    //sprawdzamy, czy checkbox jest zaznaczony, jak tak to wchodzimy
            {
                //Sortowanie bąbelkowe            
                sw.Start(); //czas dla pojedynczego sortowania start
                sortowanieBabelkowe = algorytmSortowanieBabelkowe(sortowanieBabelkowe, iloscLiczb); //wywołanie funkcji sortującej
                sw.Stop();  //czas dla pojedynczego sortowania stop
                textBox2.Text = sw.ElapsedMilliseconds.ToString();  //tutaj zapisujemy do textboxu czas z timera
                textBox2.Update();
            }

            if (quickCheck.Checked) //sprawdzamy, czy checkbox jest zaznaczony, jak tak to wchodzimy
            {
                //Sortowanie  quicksort
                sw.Reset(); //reset timera dla pojedynczego sortowania
                sw.Start(); //czas dla pojedynczego sortowania start
                quickSort = algorytmQuickSort(quickSort, 0, iloscLiczb - 1);    //wywołanie funkcji sortującej
                sw.Stop();  //czas dla pojedynczego sortowania stop
                textBox3.Text = sw.ElapsedMilliseconds.ToString();  //tutaj zapisujemy do textboxu czas z timera
                textBox3.Update();  //musimy jeszcze odswiezyc textbox
            }

            if (insertCheck.Checked)    //sprawdzamy, czy checkbox jest zaznaczony, jak tak to wchodzimy
            {
                //Sortowanie insert Sort
                sw.Reset(); //reset timera dla pojedynczego sortowania
                sw.Start(); //czas dla pojedynczego sortowania start
                instertSort = algorytmInsertSort(instertSort, iloscLiczb);  //wywołanie funkcji sortującej
                sw.Stop();  //czas dla pojedynczego sortowania stop
                textBox4.Text = sw.ElapsedMilliseconds.ToString();  //tutaj zapisujemy do textboxu czas z timera
                textBox4.Update();  //musimy jeszcze odswiezyc textbox
            }

            if (mergeCheck.Checked) //sprawdzamy, czy checkbox jest zaznaczony, jak tak to wchodzimy
            {
                //Sortowanie merge Sort
                sw.Reset(); //reset timera dla pojedynczego sortowania
                sw.Start(); //czas dla pojedynczego sortowania start
                algorytmMergeSort(0, iloscLiczb - 1);   //wywołanie funkcji sortującej
                sw.Stop();  //czas dla pojedynczego sortowania stop
                textBox5.Text = sw.ElapsedMilliseconds.ToString();  //tutaj zapisujemy do textboxu czas z timera
                textBox5.Update();  //musimy jeszcze odswiezyc textbox
            }

            if (bitonicCheck.Checked)   //sprawdzamy, czy checkbox jest zaznaczony, jak tak to wchodzimy
            {
                //Sortowanie merge Sort
                sw.Reset(); //reset timera dla pojedynczego sortowania
                sw.Start(); //czas dla pojedynczego sortowania start
                bitonicSort(bitonicTab, 0, iloscLiczb, true);   //wywołanie funkcji sortującej
                sw.Stop();  //czas dla pojedynczego sortowania stop
                textBox13.Text = sw.ElapsedMilliseconds.ToString(); //tutaj zapisujemy do textboxu czas z timera
                textBox13.Update(); //musimy jeszcze odswiezyc textbox
            }

            calkowityCzas.Stop();   //czas stop
            textBox6.Text = calkowityCzas.ElapsedMilliseconds.ToString();   //tutaj zapisujemy do textboxu czas z timera
            textBox6.Update();  //musimy jeszcze odswiezyc textbox

            Cursor.Current = Cursors.Default;   //zmienieamy kursor na normalny, domyślny
        }

        //przycisk sortowanie wielowatkowe
        //myślę, że nie ma co tutaj się za bardzo rozpisywać, wszystko dzieje się dokładnie tak jak wyżej z tą różnicą, że inne fukcje sortujące są wywoływane
        private void button8_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < iloscLiczb; i++)
            {
                sortowanieBabelkowe[i] = tablicaLiczb[i];
                instertSort[i] = tablicaLiczb[i];
                mergeSort[i] = tablicaLiczb[i];
                quickSort[i] = tablicaLiczb[i];
                bitonicTab[i] = tablicaLiczb[i];
            }

            Cursor.Current = Cursors.WaitCursor;

            Stopwatch sw = new Stopwatch();
            Stopwatch calkowityCzas = new Stopwatch();

            calkowityCzas.Start();

            if (bubbleCheck.Checked)
            {
                //Sortowanie bubble Sort
                sw.Reset();
                sw.Start();
                sortowanieBabelkowe = rownoolegleSortowanieBalbelkowe(sortowanieBabelkowe, iloscLiczb);
                sw.Stop();
                textBox11.Text = sw.ElapsedMilliseconds.ToString();
                textBox11.Update();
            }

            if (quickCheck.Checked)
            {
                //Sortowanie quicksort
                sw.Reset();
                sw.Start();
                algorytmRownoleglyQuickSort(quickSort, 0, iloscLiczb - 1, Environment.ProcessorCount);
                sw.Stop();
                textBox10.Text = sw.ElapsedMilliseconds.ToString();
                textBox10.Update();
            }

            if (insertCheck.Checked)
            {
                sw.Reset();
                sw.Start();
                instertSort = rownoleglyAlgorytmInsertSort(instertSort, iloscLiczb);
                sw.Stop();
                textBox9.Text = sw.ElapsedMilliseconds.ToString();
                textBox9.Update();
            }

            if (mergeCheck.Checked)
            {
                sw.Reset();
                sw.Start();
                algorytmRownoleglyMergeSort(0, iloscLiczb - 1, Environment.ProcessorCount);
                sw.Stop();
                textBox8.Text = sw.ElapsedMilliseconds.ToString();
                textBox8.Update();
            }

            if (bitonicCheck.Checked)
            {
                sw.Reset();
                sw.Start();
                rownoleglyBitonicSort(bitonicTab, 0, iloscLiczb, true);
                sw.Stop();
                textBox12.Text = sw.ElapsedMilliseconds.ToString();
                textBox12.Update();
            }

            calkowityCzas.Stop();
            textBox7.Text = calkowityCzas.ElapsedMilliseconds.ToString();
            textBox7.Update();

            Cursor.Current = Cursors.Default;
        }



        ////////////////////////////Algorytmy sortujące - jednowątkowe ///////////////////////////////

        //bubble sort

        private int[] algorytmSortowanieBabelkowe(int[] T, int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n - 1; j++)
                {
                    if (T[j] > T[j + 1])
                    {
                        int temp = T[j];
                        T[j] = T[j + 1];
                        T[j + 1] = temp;
                    }
                }
            }
            return T;
        }

        //insert sort

        private int[] algorytmInsertSort(int[] T, int n)
        {
            int i, j, x;
            for(j = iloscLiczb - 2; j >= 0; j--)
            {
                x = T[j];
                i = j + 1;
                while ((i < iloscLiczb) && (x > T[i]))
                {
                    T[i - 1] = T[i];
                    i++;
                }
                T[i - 1] = x;
            }
            return T;
        }

        //quick sort

        private int[] algorytmQuickSort(int[] T, int lewy, int prawy)
        {
            if (lewy >= prawy)
            {
                return T;
            }

            int i = lewy;
            int j = prawy;
            int pivot = T[(lewy + prawy) / 2];
            do
            {
                while (T[i] < pivot) i++;
                while (T[j] > pivot) j--;
                if (i <= j)
                {
                    int temp = T[i];
                    T[i] = T[j];
                    T[j] = temp;
                    i++;
                    j--;
                }
            } while (i <= j);

            algorytmQuickSort(T, lewy, j);
            algorytmQuickSort(T, i, prawy);
            return T;
        }

        //bitonic sort

        public static void compAndSwap(int[] T, int i, int j, bool dir)
        {
            bool k;
            if ((T[i] > T[j]))
                k = true;
            else
                k = false;
            if (dir == k)
            {
                int temp;
                temp = T[i];
                T[i] = T[j];
                T[j] = temp;
            }
        }

        public static void bitonicMerge(int[] T, int low, int cnt, bool dir)
        {
            if (cnt > 1)
            {
                int m = najwiekszaPotegaMniejszaOd(cnt);

                for (int i = low; i < (low + cnt - m); i++)
                    compAndSwap(T, i, i + m, dir);

                bitonicMerge(T, low, m, dir);
                bitonicMerge(T, low + m, cnt - m, dir);
            }
        }

        public static void bitonicSort(int[] T, int low, int cnt, bool dir)
        {
            if (cnt > 1)
            {
                int k = cnt / 2;

                // sort in ascending order since dir here is 1  
                bitonicSort(T, low, k, !dir);

                // sort in descending order since dir here is 0  
                bitonicSort(T, low + k, cnt - k, dir);

                // Will merge wole sequence in ascending order  
                // since dir=1.  
                bitonicMerge(T, low, cnt, dir);
            }
        }

        private static int najwiekszaPotegaMniejszaOd(int n)
        {
            int potega = 1;

            while (potega > 0 && potega < n)
                potega = potega << 1;

            return potega >> 1;
        }

        //merge sort

        void algorytmMergeSort(int l, int r)
        {
            if (l < r)
            {
                //obliczaine polowy przedzialu
                // to samo co (l+r)/2, ale chroni przed wyjsciem poza zakres int przy 
                // duzym l i h 
                int m = l + (r - l) / 2;

                // rekurencyjne sortowanie pierwszej i drugiej polowki
                algorytmMergeSort(l, m);
                algorytmMergeSort(m + 1, r);

                merge(l, m, r);
            }
        }

        void merge(int l, int m, int r)
        {
            int i, j, k;
            int n1 = m - l + 1;
            int n2 = r - m;

            // tymczasowe tablice pomocnicze
            int[] L = new int[n1];
            int[] R = new int[n2];

            //wypelnienie tymczasowych tablic
            for (i = 0; i < n1; i++)
                L[i] = mergeSort[l + i];
            for (j = 0; j < n2; j++)
                R[j] = mergeSort[m + 1 + j];

            // Scalenie tablic pomocniczych do tablicy T[l..r]
            i = 0; //indeks poczatkowy pierwszej tablicy pomocniczej
            j = 0; //indeks poczatkowy drugiej tablicy pomocniczej
            k = l; //indeks poczatkowy scalonej tablicy
            while (i < n1 && j < n2)
            {
                if (L[i] <= R[j])
                {
                    mergeSort[k] = L[i];
                    i++;
                }
                else
                {
                    mergeSort[k] = R[j];
                    j++;
                }
                k++;
            }

            //kopiowanie reszty tablicy L[], o ile cos w niej zostalo
            while (i < n1)
            {
                mergeSort[k] = L[i];
                i++;
                k++;
            }

            //kopiowanie reszty tablicy R[], o ile cos w niej zostalo
            while (j < n2)
            {
                mergeSort[k] = R[j];
                j++;
                k++;
            }
        } 

        ////////////////////////////Algorytmy sortujące - wielowątkowe ///////////////////////////////

        //insert sort

        private void krok1RownoleglyAlgorytmInsertSort(int[] T, int i)
        {
            if (T[i] < T[i - 1])
                {
                    int temp = T[i];
                    T[i] = T[i - 1];
                    T[i - 1] = temp;
                }
        }

        private void krok2RownoleglyAlgorytmInsertSort(int[] T, int i)
        {
            int j = i;
            int v = T[i];
            while (v < T[j - 1])
            {
                T[j] = T[j - 1];
                j--;
            }
            T[j] = v;
        }

        private int[] rownoleglyAlgorytmInsertSort(int[] T, int n)
        {
            for (int i = iloscLiczb - 1; i > 0; i--)
            {
                //k = iloscLiczb - 1;
                /*if (T[i] < T[i - 1])
                {
                    int temp = T[i];
                    T[i] = T[i - 1];
                    T[i - 1] = temp;
                }*/

                Parallel.Invoke(
                    () => krok1RownoleglyAlgorytmInsertSort(T, i));
            }

            for (int i = 2; i <= (iloscLiczb - 1); i++)
            {
                /*int j = i;
                int v = T[i];
                while (v < T[j - 1])
                {
                    T[j] = T[j - 1];
                    j--;
                }
                T[j] = v;*/

                Parallel.Invoke(
                    () => krok2RownoleglyAlgorytmInsertSort(T, i)); 
            }

            return T;
        }

        //quick sort

        private void algorytmRownoleglyQuickSort(int[] T, int lewy, int prawy, int glebokoscWatkow)
        {

            if (lewy >= prawy)
            {
                return;
            }

            int i = lewy;
            int j = prawy;
            int pivot = T[(lewy + prawy) / 2];
            do
            {
                while (T[i] < pivot) i++;
                while (T[j] > pivot) j--;
                if (i <= j)
                {
                    int temp = T[i];
                    T[i] = T[j];
                    T[j] = temp;
                    i++;
                    j--;
                }
            } while (i <= j);

            if (glebokoscWatkow < 1)
            {
                algorytmRownoleglyQuickSort(T, lewy, j, glebokoscWatkow);
                algorytmRownoleglyQuickSort(T, i, prawy, glebokoscWatkow);
            }
            else
            {
                glebokoscWatkow--;
                Parallel.Invoke(
                    () => algorytmRownoleglyQuickSort(T, lewy, j, glebokoscWatkow),
                    () => algorytmRownoleglyQuickSort(T, i, prawy, glebokoscWatkow));
            }           
        }

        //bitonic sort

        public static void rownoleglyBitonicMerge(int[] T, int low, int cnt, bool dir)
        {
            if (cnt > 500)
            {
                int m = najwiekszaPotegaMniejszaOd(cnt);

                for (int i = low; i < (low + cnt - m); i++)
                    compAndSwap(T, i, i + m, dir);
                Parallel.Invoke(
                        () => rownoleglyBitonicMerge(T, low, m, dir),
                        () => rownoleglyBitonicMerge(T, low + m, cnt - m, dir));
            }
            else if (cnt > 1)
            {
                bitonicMerge(T, low, cnt, dir);
            }
        }

        public static void rownoleglyBitonicSort(int[] T, int low, int cnt, bool dir)
        {
            if (cnt > 1)
            {
                int k = cnt / 2;

               Parallel.Invoke(
                        () => rownoleglyBitonicSort(T, low, k, !dir),
                        () => rownoleglyBitonicSort(T, low + k, cnt - k, dir));

                // Will merge wole sequence in ascending order  
                // since dir=1.  
               rownoleglyBitonicMerge(T, low, cnt, dir);
            }
        }  

        //merge sort

        void algorytmRownoleglyMergeSort(int l, int r, int glebokosc)
        {
            if (l < r)
            {
                //obliczaine polowy przedzialu
                // to samo co (l+r)/2, ale chroni przed wyjsciem poza zakres int przy 
                // duzym l i r 
                int m = l + (r - l) / 2;

                if (glebokosc < 1)
                {
                    algorytmRownoleglyMergeSort(l, m, glebokosc);
                    algorytmRownoleglyMergeSort(m + 1, r, glebokosc);
                }
                else
                {
                    glebokosc--;
                    Parallel.Invoke(
                        () => algorytmRownoleglyMergeSort(l, m, glebokosc),
                        () => algorytmRownoleglyMergeSort(m + 1, r, glebokosc));
                       
                }
                merge(l, m, r);
            }
        }   
      
        //bubble sort

        private int[] rownoolegleSortowanieBalbelkowe(int [] T, int n)
        {
            Parallel.For (0, n, i =>
            {      
                for (int j = 0; j < n - 1; j++)
                {
                    if (T[j] > T[j + 1])
                    {
                        int temp = T[j];
                        T[j] = T[j + 1];
                        T[j + 1] = temp; 
                    }
                }
            });
            return T;
        }

    }
}
